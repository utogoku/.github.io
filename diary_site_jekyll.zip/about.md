---
layout: default
title: About
permalink: /about/
---
<section class="page-intro"><div class="eyebrow">PROFILE</div><h1>About</h1><p>このサイトについて。</p></section>
<div class="article-body">
ここは、日々の出来事や考えたことを書き留めるための個人サイトです。

映画や本、旅のことなども記録していきます。

<!-- この文章を好きな自己紹介に書き換えてください。 -->
</div>
