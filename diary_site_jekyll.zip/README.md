# 余白の日記 — GitHub Pages 用サイト

文章を Markdown で書き足していく個人サイトです。**HTML を毎回編集する必要はありません。**

## 最初に公開する方法（パソコン推奨）

1. GitHub（https://github.com/ ）で無料アカウントを作る。
2. 新しい **Public** リポジトリを作る。名前は例として `my-diary`。
3. この ZIP を展開し、中のファイルとフォルダをリポジトリの一番上にアップロードする（ZIP ファイル自体をアップロードしない）。
4. `_config.yml` の `baseurl: ""` を `baseurl: "/my-diary"` に変更する。リポジトリ名が異なる場合はその名前に合わせる。**`ユーザー名.github.io` という名前のリポジトリなら空欄のままで OK。**
5. リポジトリの **Settings → Pages → Build and deployment** で **Deploy from a branch**、**main**、**/(root)** を選び Save。
6. 公開アドレスは通常 `https://ユーザー名.github.io/my-diary/`。反映まで少し時間がかかる場合があります。

※ 公開リポジトリ内の原稿は誰でも閲覧できます。住所、電話番号、他人の個人情報、非公開にしたい日記はアップロードしないでください。

## 日記を投稿するには

1. GitHub の `_posts` フォルダを開いて **Add file → Create new file**。
2. ファイル名を `2026-10-16-my-day.md` のように、**半角の年月日-英数字のタイトル.md** にする。
3. 次の文章を貼って編集する。`date` は日付と時間、`categories` は `diary` か `notes` にする。

```markdown
---
layout: post
title: "今日の日記"
date: 2026-10-16 19:00:00 +0900
categories: [diary]
---

今日はこんなことがあった。

## 小見出し

文章を続ける。**太字**も使える。
```

4. **Commit changes** で保存。サイトの一覧と記事ページに自動的に反映されます。

スマホからも GitHub の Web サイトで同じ操作ができます。たくさん書く場合はパソコンが便利です。

## 内容を変更するには

- サイト名・説明：`_config.yml`
- 自己紹介：`about.md`
- 最初のサンプル記事：`_posts` 内の2つの `.md` ファイル（不要なら削除可能）
- 文章の見た目：`assets/style.css`
- トップページの説明文：`index.html`

## パソコンで表示を試す（任意）

Ruby と Bundler が入っている場合、ターミナルで `bundle install` の後 `bundle exec jekyll serve` を実行し、 `http://localhost:4000` にアクセスできます。`index.html` を直接開くだけでは Jekyll のテンプレートは動きません。GitHub Pages に公開すると表示されます。
